<style>
 .gender{
    color:#fff;
    background-color: #000;
    border: 2px solid #fff;
    border-top: none;
  }
   .gender, .gender__list{
    padding: 20px;
  }
  .gender__list{
    position: relative;
    border: 2px solid #000;
  }
  .gender__form{
    margin:0 auto;
    width: 250px;
    text-align: center;
  }
  span{
    width: 15px;
    height: 15px;
    position: absolute;
    right: 5%;
    top:35%;
    border-top: 2px solid;
    border-left: 2px solid;
    transform: rotate(225deg);
    transition: transform 0.5s ease; 
  }
   .gender__list.active span{
    transform: rotate(45deg);
    top:35%;
  }
</style>
<template>
  <div class="gender__form">
    <div class="gender__list"
         @click="showGender = !showGender, isSelected = !isSelected"
         :class="{'active': isSelected}">
      {{value ? value : 'Укажите ваш пол'}}
      <span></span>
    </div>
    <div class="gender"
         v-show="showGender"
         v-for="(val, key) in selectGender"
         :key="key"
         :label="val"
         @click="selected(val)"
    >{{ val }}</div>
  </div>
</template>

<script>
export default {
  name: "SelectGender.vue",
  props: {
    selectGender: {
      type: Object
    },
    select: {
      default: false
    },
    value: {
      default: false
    }
  },
  data(){
    return {
      showGender: false,
      isSelected: false
    }
  },
  methods: {
    selected(Val) {
      this.showGender = !this.showGender
      this.isSelected = !this.isSelected
      this.$emit('update:value', Val )
    }
  }
}
</script>

