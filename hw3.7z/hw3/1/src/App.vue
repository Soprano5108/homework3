<style>
#app {
  font-size:20px;
  color: #2c3e50;
  margin-top:10%
}
</style>

<template>
  <div id="app">
    <Select :value.sync="customSelect" :selectGender="selectGender"/>
  </div>
</template>

<script>
import Select from './components/SelectGender'
export default {
  name: 'App',
  components: {
    Select
  },
  data(){
    return{
      selectGender: {
        male: 'мужской',
        female: 'женский',
        other: 'другой'
      },
      customSelect: ''
    }
  }
}
</script>


