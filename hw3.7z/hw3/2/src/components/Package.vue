<template>
  <form @submit.prevent="$emit('onSubmit')">
    <slot name="Select"></slot>
    <slot name="title"></slot>
    <slot name="InputForms"></slot>
    <slot name="Radio"></slot>
    <slot name="Checkbox"></slot>
    <slot name="btnConfirm"></slot>
  </form>
</template>

<script>
export default {
name: "Package"
}
</script>

<style scoped>

</style>