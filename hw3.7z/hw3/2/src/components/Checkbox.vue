<style scoped>
.agreePack{
text-align:center;
padding:15px;
}
</style>

<template>
  <div class="agreePack">
    <label>
      <input
          type="checkbox"
          :value="value"
          :checked="isChecked"
          @change="update"
      >
      <span>{{label}}</span>
    </label>
  </div>
</template>

<script>
export default {
  name: "Checkbox",
  model: {
    event: 'change',
    prop: 'valq'
  },
  props: {
    value: String,
    valT: String,
    valF: String,
  label: String,
    valq: {
      default: ''
    }
  },
  computed: {
    isChecked() {
      if(this.valq instanceof Array) {
        return this.valq.includes(this.value)
      }
      return this.valq === this.value
    }
  },
  methods: {
    update(e) {
      let isCheck = e.target.checked;

      if(this.valq instanceof Array) {
        let value = [...this.valq];

        if(isCheck) {
          value.push(this.value)
        } else {
          value.splice(value.indexOf(this.value))
        }

        this.$emit('change', value)
      } else {
        this.$emit('change', isCheck ? this.valT : this.valF);
      }
    }
  }
}
</script>

