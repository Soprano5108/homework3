<style scoped>
  .radioPack{
    text-align: center;
  }
</style>

<template>
  <div class="radioPack">
    <label>
      <input
          type="radio"
          :value="value"
          :checked="isChecked"
          @change="$emit('change', $event.target.value)"
      >
      <span>{{label}}</span>
    </label>
  </div>
</template>

<script>
export default {
 name: "Radio",
  model: {
    event: 'change',
    prop: 'valq'
  },
  props: {
    value: String,
    label: String,
    valq: {
      default: ''
    },

  },
  computed: {
    isChecked() {
      return this.valq === this.value
    }
  }
}
</script>

