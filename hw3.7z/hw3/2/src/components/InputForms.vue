<template>
  <div class="inputForm">
    <label>
      <span>{{ label }}</span>
      <input :type="type" :value="value" @input="$emit('update:value', $event.target.value)">
    </label>
  </div>
</template>

<script>
export default {
  name: "InputForms",
  props: {
        value: String,
        label: String,
    type: {
        default: 'text',
        type: String,
      
    }
  }
}
</script>

<style scoped>
  .inputForm{
    margin: 10px 0;
  }
  .inputForm label{
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    width: 250px;
    margin: auto;
  }
</style>