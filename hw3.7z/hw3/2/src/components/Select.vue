<style scoped>
  .selectPack{
    width: 300px;
    text-align: center;
    margin: 20px auto;
  }
  .language, .Select{
    padding: 10px 20px;

  }
  .Select{
    position: relative;
    border: 1px solid #ccc;
    background: #fff;
  }
  .Select.active span{
    transform: rotate(45deg);
  }
  span{
    position: absolute;
    right: 10%;
    width: 15px;
    height: 15px;
    border-top: 2px solid;
    border-left: 2px solid;
    transition:transform 0.5s ease-out;
    transform: rotate(225deg);
  }
  .language{
    background: #000;
    border: 1px solid #ccc;
    border-top: none;
    border-radius:30px;
    color:#fff
  }

</style>
<template>
  <div class="selectPack">
    <div class="Select"
         @click="showlanguages = !showlanguages, isSelected = !isSelected"
         :class="{'active': isSelected}">
      {{value ? value : 'Язык'}}
      <span></span>
    </div>
    <div class="language"
         v-show="showlanguages"
         v-for="(val, key) in lang"
         :key="key"
         :label="val"
         @click="selected(val)"
    >{{ val }}</div>
  </div>
</template>

<script>
export default {
  name: 'select',
  props: {
    lang: {
      type: Array
    },
    select: {
      default: false
    },
    value: {
      default: false
    }
  },
  data(){
    return {
      showlanguages: false,
      isSelected: false
    }
  },
  methods: {
    selected(val) {
      this.showlanguages = !this.showlanguages
      this.isSelected = !this.isSelected
      this.$emit('update:value', val )
    }
  }
}
</script>

