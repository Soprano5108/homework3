<style>
button{
min-width:100px;
  background: #000;
  padding: 20px;
  border-radius:30px;
  color: #fff;
}
.Select{
  border-radius:30px;
}
input{
    border-radius:30px;
}
.btn{
  margin: 15px;
  text-align: center;
}
.notConfirm{
  text-align: center;
}
.confirm{
  margin-top:20%;
  text-align: center;
}
.inputForm{
margin-top:15
}
form{
  margin: auto;
}



</style>
<template>
  <div id="app">
    <h1 v-if="formConfirm" class="confirm">Отправка формы успешна</h1>
    <Package v-show="showForm" @onSubmit="onSubmit">
      <template #InputForms>
        <inputForms v-model="userAdd.name" :value.sync="userAdd.name" label="Имя"/>
        <inputForms v-model="userAdd.surname" :value.sync="userAdd.surname" label="Фамилия"/>
        <inputForms v-model="userAdd.email" :value.sync="userAdd.email" label="Email"/>
        <div v-if="emailError" class="notConfirm">Введите свою почту</div>
      </template>
      <template #Select>
        <Select :value.sync="userAdd.lang" :lang="lang"/>
      </template>
      <template #Radio>
        <Radio v-model="userAdd.gender" v-for="i in gender" :key="i" :label="i" :value="i"/>
      </template>
      <template #Checkbox>
        <Checkbox v-model="userAdd.agree" label="Подтвердите согласие" val-t="true" val-f="false"/>
        <div v-if="checkboxError" class="notConfirm">Необходимо подтвердить свое согласие</div>
      </template>
      <template #btnConfirm>
        <div class="btn">
          <button type="submit">{{btnConfirm}}</button>
        </div>
      </template>
    </Package>
  </div>
</template>

<script>
import Package from "./components/Package";
import Select from "./components/Select";
import InputForms from "./components/InputForms";
import Radio from "./components/Radio";
import Checkbox from "./components/Checkbox";
export default {
  name: 'App',
  components: {
    Radio, Package, InputForms, Select, Checkbox
  },
  data(){
    return {
      userAdd: {
        id: '',
        name: '',
        surname: '',
        email: '',
        lang: '',
        gender: '',
        agree: ''
      },
      inputForms: ['name', 'surname', 'email'],
      lang: ['Английский', 'Русский', 'Французский'],
      gender: {
        male: 'Мужской',
        female: 'Женский',
        other: 'Другой'
      },
      showForm: true,
      emailError: false,
      checkboxError: false,
      formConfirm: '',
      notFormConfirm: '',
      btnConfirm: 'Отправить форму'
    }
  },
  methods:{
    onSubmit(){
      this.btnConfirm = 'Отправка'
      setTimeout(() => {
        this.checkboxError = false
        this.emailError = false
        this.userAdd.id = Math.floor(Math.random() * Math.floor(1000))
        if(this.userAdd.email && this.userAdd.agree){
          this.showForm = false
          if(this.userAdd.name && this.userAdd.surname){
            this.formConfirm = true
            this.notFormConfirm = false
            console.log(
              `[id]: ${this.userAdd.id}
[name]: ${this.userAdd.name}
[surname]: ${this.userAdd.surname}
[email]: ${this.userAdd.email}
[lang]: ${this.userAdd.lang}
[gender]: ${this.userAdd.gender}
[agree]: ${this.userAdd.agree}`)
          }
          else{
            this.formConfirm = false
            this.notFormConfirm = true
          }
        }
        else {
          this.btnConfirm = 'Отправить форму'
          if(!this.userAdd.email){
            this.emailError = true
          }
          if(!this.userAdd.agree){
            this.checkboxError = true
          }
        }
      }, 2000)
    }
  }
}
</script>


